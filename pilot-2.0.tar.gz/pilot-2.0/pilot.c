/***************************************************************************
 * Copyright (c) 2008-2011 University of Guelph.
 *                         All rights reserved.
 *
 * This file is part of the Pilot software package.  For license
 * information, see the LICENSE file in the top level directory of the
 * Pilot source distribution.
 **************************************************************************/

/*!
********************************************************************************
\file pilot.c
\author John Douglas Carter
\author Bill Gardner
\author Emmanuel MacCaull

\brief Implementation file for Pilot

[9-Mar-09] Fixed bug #21: PI_Gather triggers stack out-of-bounds seg fault
	with large array. Switched to MPI_Gatherv. V0.1 (BG)
[30-May-09] Fixed bug #25: PI_Read/Write doesn't realize when channel part
	of non-Selector bundle. V1.0 (BG)
[10-July-09] Fixed bug #22,#23: Too-long format string can overflow buffer;
	ParseFormatStrings not picky enough. V1.0 (EM)
[22-Nov-09] Add support for Fortran data types. V1.1f (BG)
[23-Nov-09] Allow PI_GetName to be called anytime. V1.1f (BG)
[6-Dec-09] Use MPI_Ssend when deadlock checking enabled to match CSP unbuffered
	channel semantics and prevent "false positives". V1.1f (BG)
[9-Jan-10] Fixed #33: Fortran data type symbols missing from mpi.h in
	Open MPI. Check MPID_NO_FORTRAN. Also, no MPI_IN_PLACE in LAM. V1.2 (BG)
[16-Jan-10] *Some* Fortran data type symbols missing from mpi.h in HP MPI.
	#define *most* missing ones following the pattern for MPI_INTEGER,
	and the "new ones" from mpif.h. V1.2a (BG)
[13-May-11] Fixed #28: CreateBundle fails to detect reincorporation of same
	channels into 2nd bundle. Needed new error PI_BUNDLE_ALREADY. V2.0 (BG)
[15-May-11] Fixed #38: PI_GetMyRank was undocumented API, only used by test
	suites, which didn't really need it => removed. V2.0 (BG)
[15-May-11] Fixed #30: confusing for a corrupted object in ISVALID assertion
	to throw "system error". Change cases where arg points to invalid object
	to PI_INVALID_OBJ (could be wrong pointer or corruption), and make
	new PI_MPI_ERROR for that case (could be misuse of MPI by Pilot, or
	MPI detecting user error). V2.0 (BG)
[16-May-11] Fixed #31: Try to keep Pilot messages separate from MPI msgs to
	avoid confusion. Print using new PI_BORDER macro (pilot_private.h).
	V2.0 (BG)
[25-May-11] Added PI_Scatter & PI_Reduce. TODO: Add regression/deadlock tests.
	Add to Fortran API. V2.0 (BG)
*******************************************************************************/

#include "pilot_private.h"	// include these typedefs first

#define PI_NO_OPAQUE		// suppress typedefs in public pilot.h
#include "pilot.h"

#define DEF_ERROR_TEXT      // generate storage for error text array
#include "pilot_error.h"

/* headers for online processes */
#include "pilot_deadlock.h"

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>

/*** Pilot global variables ***/

int PI_QuietMode = 0;		// quiet mode off
int PI_CheckLevel = 1;		// default level of checking
int PI_OnErrorReturn = 0;	// on any error, abort program
int PI_Errno = PI_NO_ERROR;	// error code returned here (if no abort)
const char *PI_CallerFile;	// filename of caller (set by macro)
int PI_CallerLine;		// line no. of caller (set by macro)

/*** Forward declarations of internal-use functions ***/
static void HandleMPIErrors( MPI_Comm *comm, int *code, ... );
static char *ParseArgs( int *argc, char ***argv );
static void *OnlineThreadFunc( void *arg );
static int OnlineProcessFunc( int a1, void *a2 );
static int ParseFormatString( IO_CONTEXT valsOrLocs, PI_MPI_RTTI meta[], const char *fmt, va_list ap );

/*** Logging facility ***/
typedef enum { PILOT='P', USER='U', TABLES='T', CALLS='C', STATS='S' } LOGEVENT;
static void LogEvent( LOGEVENT ev, const char *event );


#define LOUD if( !PI_QuietMode )


/*!
********************************************************************************
\brief Copy of the environment for this Pilot process.

Holds processes, channels and internal variables.  Each process
will possess the same environment at PI_StartAll(), then local updates will
occur for bookkeeping purposes as reads/writes take place.
*******************************************************************************/
static PI_PROCENVT thisproc = { .phase=PREINIT };

static int MPICallLine;	/*!< line number of last MPI library call (PI_CALLMPI macro) */
static int MPIMaxTag;	/*!< max tag number allowed by this MPI implementation */
static int MPIPreInit;	/*!< non-0 if MPI already initialized when Pilot invoked */
static int (*MPISender)(void*, int, MPI_Datatype, int, int, MPI_Comm);	/*!< function used for PI_Write */

static pthread_t OnlineThreadID; /*!< ID of online thread, if any */

/* Command-line options:
These variables are only meaningful on node 0 (and we assume that only
node 0 can write files).  The resulting service flag settings are broadcast
to other processes to store in their PI_PROCENVT, where they will be checked
during PI_ API calls.  These variables are not used after PI_Configure.
*/
static char *LogFilename;	/*!< Path to log file. NULL = no log file needed. */
static enum {OLP_NONE, OLP_THREAD, OLP_PILOT} OnlineProcess;
enum {OPT_CALLS=0, OPT_STATS, OPT_TOPO, OPT_TRACE, OPT_DEADLOCK, OPT_END};
static Flag_t Option[OPT_END];	/*!< List of command-line options. 1/0 = flag set/clear */


/*** Public API; each PI_Foo_ is called via PI_Foo wrapper macro ***/

/* Functions that can be called anytime because we don't check the phase.
   Probably we should at least insist on post-PI_Configure. */

void PI_StartTime( void )
{
    thisproc.start_time = MPI_Wtime( );
}

double PI_EndTime( void )
{
    double now = MPI_Wtime( );

    if ( thisproc.start_time > 0.0 )
        return (now - thisproc.start_time);

    fprintf( stderr, "\n" PI_BORDER
		"PI_EndTime: Timing not initialized.  Call PI_StartTime() first." );
    return 0.0;
}

int PI_IsLogging()
{
    return thisproc.svc_flag[OLP_LOGFILE];
}

const char *PI_GetName_(const void *object)
{
    static const char *noname = "Configuration Phase";

    PI_ON_ERROR_RETURN( NULL )

    /* special case NULL object -> name of this process */

    if ( object == NULL ) {
	if ( thisproc.phase==RUNNING )
	    return thisproc.processes[thisproc.rank].name;
	else
	    return noname;
    }

    /* probe magic number to identify object type */

    if ( ISVALID(PI_PROC,(PI_PROCESS*)object) )
	return ((PI_PROCESS*)object)->name;

    if ( ISVALID(PI_CHAN,(PI_CHANNEL*)object) )
	return ((PI_CHANNEL*)object)->name;

    if ( ISVALID(PI_BUND,(PI_BUNDLE*)object) )
	return ((PI_BUNDLE*)object)->name;

    PI_ASSERT( , 0, PI_INVALID_OBJ )	// can't identify it -> abort
    return NULL;	// to make compiler not warn
}


/* Setup functions, to call before StartAll */

int PI_Configure_( int *argc, char ***argv )
{
    int i;
    int provided;	// level of thread support provided by MPI

    PI_ON_ERROR_RETURN( 0 )
    PI_ASSERT( , thisproc.phase==PREINIT, PI_WRONG_PHASE )

    thisproc.phase = CONFIG;
    thisproc.start_time = -1.0;

    /* Process command line arguments into LogFilename, OnlineProcess, and
       Option array.  May override caller's setting of PI_CheckLevel.
       This removes any recognized by Pilot.  MPI_Init will do the same with
       whatever are left.  The user's app can scan anything remaining.  This
       may change *argc and shuffle the array of char* in *argv.  If we're not
       running on node 0, there may be no arguments.  We'll only use the results
       on node 0 below.  (We don't know which node we are since MPI isn't
       initialized yet!)
    */
    char *badargs = ParseArgs( argc, argv );	// return needs to be freed

    /* Unless we're in "bench mode" (MPI already initialized), we next init MPI.
       If we need the thread-based online process (because of writing a log
       file), we have to specify the threaded version for node 0.  Unfortunately,
       if we're not node and the arguments _were_ conveyed and parsed, this will
       result in (needlessly) starting the threaded version on ALL nodes; there's
       no way around this.  If the user knows that files can be written from
       non-0 nodes, then the Pilot-based online process can be selected, which
       will avoid starting the threaded version.
    */
    MPI_Initialized( &MPIPreInit );	/* did user already initialize MPI? */
    if ( !MPIPreInit ) {
        MPI_Init_thread( argc, argv,
                         OnlineProcess==OLP_THREAD ? MPI_THREAD_MULTIPLE : MPI_THREAD_SINGLE,
                         &provided );		/* starts MPI */
    }
    else
        MPI_Query_thread( &provided );

    /* set up handler for any MPI error so Pilot can provide details then abort */
    MPI_Errhandler errhandler;
    MPI_Comm_create_errhandler( (MPI_Comm_errhandler_fn*)HandleMPIErrors, &errhandler );
    MPI_Comm_set_errhandler( MPI_COMM_WORLD, errhandler ); // inherited by all communicators

    MPI_Comm_rank( MPI_COMM_WORLD, &thisproc.rank );	/* get current process id */
    MPI_Comm_size( MPI_COMM_WORLD, &thisproc.worldsize );	/* get number of processes */

    /* find out what the max. tag no. can be (15 bits by standard, up to 31) */
    int *tagub, flag;
    MPI_Attr_get( MPI_COMM_WORLD, MPI_TAG_UB, &tagub, &flag );
    MPIMaxTag = flag ? *tagub : 32767;		// was attrib. defined?

    if ( thisproc.rank == 0 ) {
        if ( badargs )
            fprintf( stderr, PI_BORDER "Unrecognized arguments: %s\n", badargs );

/////////////// should following be done in ParseArgs, so worked-over value of
/////////////// OnlineProcess is available for MPI_Init?
        /* go through the options and determine their runtime implications,
           setting appropriate service flags */
        int anyopts = 0;
        for ( i=0; i<OPT_END; i++ )
            anyopts = anyopts || Option[i];

        /* determine which kinds of data must be logged to supply the service */
        thisproc.svc_flag[LOG_TABLES] = (Flag_t)( Option[OPT_CALLS] ||
            Option[OPT_STATS] || Option[OPT_TOPO] || Option[OPT_TRACE]);
        thisproc.svc_flag[LOG_CALLS] = (Flag_t)(Option[OPT_CALLS] ||
            Option[OPT_TRACE] || Option[OPT_DEADLOCK] );
        thisproc.svc_flag[LOG_STATS] = Option[OPT_STATS];

        /* services needing an online process/thread */
        thisproc.svc_flag[OLP_DEADLOCK] = Option[OPT_DEADLOCK];

        /* log file needed? use default 'pilot.log' if not specified; if
           file specified but no services turned on logging earlier, turn
           on log file after all */
        thisproc.svc_flag[OLP_LOGFILE] = (Flag_t)( Option[OPT_CALLS] ||
            Option[OPT_STATS] || Option[OPT_TOPO] || Option[OPT_TRACE] ||
            OnlineProcess != OLP_NONE );
        if ( thisproc.svc_flag[OLP_LOGFILE] ) {
            if ( NULL==LogFilename ) LogFilename = strdup( "pilot.log" );
        }
        //else if ( LogFilename ) thisproc.svc_flag[OLP_LOGFILE] = 1;

        /* determine which, if any, style of online process is needed;
           default for logfile and for deadlock is Pilot process,
           since thread support in MPIs seems to be generally lacking */
        if ( thisproc.svc_flag[OLP_LOGFILE] ) {
            if ( OnlineProcess == OLP_NONE ) OnlineProcess = OLP_PILOT;
        }
        else OnlineProcess = Option[OPT_DEADLOCK] ? OLP_PILOT : OLP_NONE;

        /* assign the OLP to rank 0 if thread, or 1 if Pilot process */
        thisproc.svc_flag[OLP_RANK] = (Flag_t)( OnlineProcess==OLP_PILOT );

        /* this is the "one stop shop" to find out if logging is enabled */
        thisproc.svc_flag[LOGGING] =
                (Flag_t)( anyopts || thisproc.svc_flag[OLP_LOGFILE] );

/* TESTING: print summary of args
        for ( i=0; i<OPT_END; i++) printf( " %d", Option[i] );
        printf( "; any = %d; olp = %d; fname = %s\n", anyopts, OnlineProcess,
                LogFilename ? LogFilename : "NULL" );
        for ( i=0; i<SVC_END; i++) printf( " %d", thisproc.svc_flag[i] );
        printf( "\n===Thread support = %d\n", provided );
********************************/

        /* say hello; suppress this via PI_QuietMode */
        LOUD {
            printf( "\n" PI_BORDER "*** %s\n", PI_HELLO );
            printf( PI_BORDER "*** Available MPI processes: %d; tags for channels: %d\n",
                    thisproc.worldsize, MPIMaxTag );
            printf( PI_BORDER "*** Running with error checking at Level %d\n", PI_CheckLevel );

            /* print the options that are in effect */
            printf( PI_BORDER "*** Command-line options:\n" PI_BORDER "***  " );
            if ( Option[OPT_CALLS] ) printf( " Call_logging" );
            if ( Option[OPT_STATS] ) printf( " Statistics" );
            if ( Option[OPT_TOPO] ) printf( " Topology" );
            if ( Option[OPT_TRACE] ) printf( " Tracing" );
            if ( Option[OPT_DEADLOCK] ) printf( " Deadlock_detection" );
            printf( "\n" );
            if ( LogFilename )
                printf( PI_BORDER "*** Logging to file: %s\n", LogFilename );
            if ( OnlineProcess==OLP_THREAD )
                printf( PI_BORDER "*** Online process running on node 0 thread\n" );
            if ( OnlineProcess==OLP_PILOT )
                printf( PI_BORDER "*** Online process running as P1\n" );
        }

        /* check to make sure that threading support is available if we need it */
        PI_ASSERT( , OnlineProcess!=OLP_THREAD || provided==MPI_THREAD_MULTIPLE,
                                               PI_THREAD_SUPPORT )
    }

    free( badargs );

    /* broadcast the options to everybody, since we can't assume they parsed
       the args for themselves */

    PI_CALLMPI( MPI_Bcast( thisproc.svc_flag, SVC_END, MPI_UNSIGNED_CHAR, PI_MAIN,
                           MPI_COMM_WORLD ) )

    /* initialize table of processes */
    thisproc.processes =
        ( PI_PROCESS * ) malloc( sizeof( PI_PROCESS ) * thisproc.worldsize );
    PI_ASSERT( , thisproc.processes, PI_MALLOC_ERROR )

    /* initialize table of process aliases: default is Pn */
    for ( i = 0; i < thisproc.worldsize; i++ ) {
        sprintf( thisproc.processes[i].name, "P%d", i );
    }

    /* initialize table of function pointers */
    for ( i = 0; i < thisproc.worldsize; i++ ) {
        thisproc.processes[i].run = NULL;
    }

    thisproc.channels = NULL;	// grow using realloc on demand

    /* allocate bundle table */
    thisproc.bundles = malloc( sizeof( PI_BUNDLE * ) * PI_MAX_BUNDLES );

    for ( i = 0; i < PI_MAX_BUNDLES; i++ ) {
        thisproc.bundles[i] = NULL;
    }

    /* initialize process, channel, bundle counts */
    thisproc.allocated_processes = 0;
    thisproc.allocated_channels = 0;
    thisproc.allocated_bundles = 0;

    /* create a place holder for rank 0 and set name */
    PI_SetName( PI_CreateProcess_( NULL, 0, NULL, 0 ), "main" );

    /* Determine which MPI function will do PI_Write; default is MPI_Send,
       which is often buffered, but could be unbuffered in some circumstances.
       Deadlock detection can't live with that uncertainty, so use MPI_Ssend
       if it's enabled, which will act unbuffered and unf'ly add overhead.
    */
    if ( Option[OPT_DEADLOCK] ) MPISender = MPI_Ssend;
    else MPISender = MPI_Send;

    /* If we need to start an online process, create it now, so it gets
       rank 1; this will abort if there aren't at least 2 MPI processes
       available.  Filename has to be sent from PI_MAIN in PI_StartAll, since
       P1 doesn't know it.
    */
    i = thisproc.worldsize;
    if ( thisproc.svc_flag[OLP_RANK] == 1 ) {
        i--;	/* decr. worldsize since OLP absorbs 1 */
        PI_SetName( PI_CreateProcess_( OnlineProcessFunc, 0, NULL, 0 ),
			"Pilot Online Process" );
    }

    return i;	/* no. of processes available to user, including PI_MAIN */
}

/* Note: Process IDs (=MPI rank) run from 0
   lang switch: 0=C (call by value), 1=Fortran (call by loc) */
PI_PROCESS *PI_CreateProcess_( PI_WORK_FUNC f, int index, void *opt_pointer,
							int lang )
{
    PI_ON_ERROR_RETURN( NULL )
    PI_ASSERT( , thisproc.phase==CONFIG, PI_WRONG_PHASE )

    /* assign the new process the next available MPI process rank */
    int r = thisproc.allocated_processes++;
    PI_ASSERT( , r<thisproc.worldsize, PI_INSUFFICIENT_MPIPROCS )

    /* must supply function unless it's the zero main process */
    PI_ASSERT( , r==0 || f!=NULL, PI_NULL_FUNCTION )
    thisproc.processes[r].run = f;
    thisproc.processes[r].call = lang;

    snprintf( thisproc.processes[r].name, PI_MAX_NAMELEN, "P%d", r ); // default name "Pn"
    thisproc.processes[r].argument = index;
    thisproc.processes[r].argument2 = opt_pointer;
    thisproc.processes[r].rank = r;
    thisproc.processes[r].magic = PI_PROC;
    return &thisproc.processes[r];
}

/* Note: Channel tags run from 1, with 0 reserved for special use, i.e.,
   log messages */
PI_CHANNEL *PI_CreateChannel_( PI_PROCESS *from, PI_PROCESS *to )
{
    PI_ON_ERROR_RETURN( NULL )
    PI_ASSERT( , thisproc.phase==CONFIG, PI_WRONG_PHASE )

    int f, t;		// MPI ranks of from/to processes

    if ( from == NULL ) {
        f = PI_MAIN;
    } else {
        PI_ASSERT( LEVEL(1), ISVALID(PI_PROC,from), PI_INVALID_OBJ )
        f = from->rank;
    }

    if ( to == NULL ) {
        t = PI_MAIN;
    } else {
        PI_ASSERT( LEVEL(1), ISVALID(PI_PROC,to), PI_INVALID_OBJ )
        t = to->rank;
    }

    PI_ASSERT( , t!=f, PI_ENDPOINT_DUPLICATE )

    PI_CHANNEL *pc = malloc( sizeof( PI_CHANNEL ) );
    PI_ASSERT( , pc, PI_MALLOC_ERROR )

    // expand array of PI_CHANNEL* pointers
    thisproc.channels = realloc( thisproc.channels,
			(1+thisproc.allocated_channels)*sizeof(PI_CHANNEL*) );
    PI_ASSERT( , thisproc.channels, PI_MALLOC_ERROR )
    thisproc.channels[thisproc.allocated_channels] = pc;

    /* channel ID & initial tag is just 1+no. allocated so far */
    pc->chan_id = pc->chan_tag = ++thisproc.allocated_channels;

    /* it's unlikely that the user will blow past this limit, but better check */
    PI_ASSERT( , pc->chan_tag<MPIMaxTag, PI_MAX_TAGS )

    pc->producer = f;
    pc->consumer = t;

    snprintf( pc->name, PI_MAX_NAMELEN,
		"C%d", pc->chan_id ); 	// default name "Cn"

    pc->bundle = NULL;		/* initially not part of bundle */
    pc->write_count = 0;
    pc->magic = PI_CHAN;

    return pc;
}

PI_BUNDLE *PI_CreateBundle_( enum PI_BUNUSE usage, PI_CHANNEL *const array[], int size )
{
    PI_ON_ERROR_RETURN( NULL )	/* makes caller func return NULL to user */
    PI_ASSERT( , thisproc.phase==CONFIG, PI_WRONG_PHASE )
    PI_ASSERT( , array, PI_NULL_CHANNEL )
    PI_ASSERT( , size>0, PI_ZERO_MEMBERS )
    PI_ASSERT( , thisproc.allocated_bundles<PI_MAX_BUNDLES, PI_MAX_BUNDLES )

    PI_BUNDLE *b = malloc( sizeof( PI_BUNDLE ) );
    PI_ASSERT( , b, PI_MALLOC_ERROR )

    /* Depending on the bundle usage, we'll extract some properties from the
       first channel and propagate them to the others in the bundle:
       - all have a common endpoint, either the producer or consumer
       - a Selector has a common tag; collective bundles don't use tags
    */
    PI_ASSERT( LEVEL(1), ISVALID(PI_CHAN,array[0]), PI_INVALID_OBJ )

    int commonEnd = (usage==PI_BROADCAST || usage==PI_SCATTER)
			? array[0]->producer : array[0]->consumer;
    int commonTag = usage==PI_SELECT ? array[0]->chan_tag : 0;

    b->usage = usage;
    b->size = size;
    b->channels = malloc( sizeof( PI_CHANNEL * ) * size );
    PI_ASSERT( , b->channels, PI_MALLOC_ERROR )

    /* copy array of channels into bundle, checking/setting properties */
    int i, j;
    for ( i = 0; i < size; i++ ) {
        PI_ASSERT( LEVEL(1), ISVALID(PI_CHAN,array[i]), PI_INVALID_OBJ )

	/* verify that channel is not already part of a bundle:
	   - NULL and chan_tag are the initial values
	*/
	PI_ASSERT( ,
	  NULL==array[i]->bundle && array[i]->chan_id==array[i]->chan_tag,
	  PI_BUNDLE_ALREADY )

        /* verify that each member channel has the required common end */
        switch ( usage ) {
          case PI_SELECT:
	  case PI_GATHER:
	  case PI_REDUCE:
            PI_ASSERT( , array[i]->consumer==commonEnd, PI_BUNDLE_READEND )
            break;

          case PI_BROADCAST:
	  case PI_SCATTER:
            PI_ASSERT( , array[i]->producer==commonEnd, PI_BUNDLE_WRITEEND )
            break;
        }

        /* verify that there are no duplicate processes on rim */
        for ( j = 0; j < i; j++ ) {
            if ( usage==PI_BROADCAST || usage==PI_SCATTER ) {
                PI_ASSERT( , array[i]->consumer!=array[j]->consumer, PI_BUNDLE_DUPLICATE )
            } else {
                PI_ASSERT( , array[i]->producer!=array[j]->producer, PI_BUNDLE_DUPLICATE )
            }
        }

        /* propagate common tag for Selector bundle */
        if ( usage == PI_SELECT )
            array[i]->chan_tag = commonTag;
        /* make each member of collective channel point to this bundle */
        else
            array[i]->bundle = b;

        b->channels[i] = array[i];	// store the channel member in bundle
    }

    b->narrow_end = (usage==PI_BROADCAST || usage==PI_SCATTER) ? FROM : TO;

    if ( usage == PI_SELECT ) {
        b->comm = MPI_COMM_WORLD;
    } else {
        /* create the communicator */
        MPI_Group world, group;

        /* get handle on WORLD comm. group */
        PI_CALLMPI( MPI_Comm_group( MPI_COMM_WORLD, &world ) )

        int *ranks = malloc( sizeof( int ) * ( b->size + 1 ) );
        PI_ASSERT( , ranks, PI_MALLOC_ERROR )

        /* fill in ranks array for new group; bundle base goes in rank 0 */
        if ( usage==PI_BROADCAST || usage==PI_SCATTER ) {
            ranks[0] = b->channels[0]->producer;
            for ( i = 1; i < ( b->size + 1 ); i++ )
                ranks[i] = b->channels[i-1]->consumer;
        } else {	/* GATHER or REDUCE */
            ranks[0] = b->channels[0]->consumer;
            for ( i = 1; i < ( b->size + 1 ); i++ )
                ranks[i] = b->channels[i-1]->producer;
        }

	if ( usage==PI_REDUCE ) {
	    /* For reduce, we leave the consumer out of the communicator,
	       because it cannot call MPI_Reduce without providing data to
	       the reduce operation -- and it doesn't have any!  So we let
	       just the producer ranks participate in MPI_Reduce.  The rank at
	       channels[0]->producer will be responsible for sending the
	       reduced result to channel[0]->consumer in a separate message.
            */
            PI_CALLMPI( MPI_Group_incl( world, b->size, &ranks[1], &group ) )
	}
	else PI_CALLMPI( MPI_Group_incl( world, b->size + 1, ranks, &group ) )
        free( ranks );

        PI_CALLMPI( MPI_Comm_create( MPI_COMM_WORLD, group, &( b->comm ) ) )
    }

    b->magic = PI_BUND;
    thisproc.bundles[thisproc.allocated_bundles] = b;

    /* bundle ID is just 1+no. allocated so far */
    b->bund_id = ++thisproc.allocated_bundles;

    snprintf( b->name, PI_MAX_NAMELEN,
		"B%d@P%d", b->bund_id, commonEnd );	// default name "Bn@Pc"

    return b;
}

PI_CHANNEL **PI_CopyChannels_( enum PI_COPYDIR direction, PI_CHANNEL *const array[], int size )
{
    PI_ON_ERROR_RETURN(NULL)
    PI_ASSERT( , thisproc.phase==CONFIG, PI_WRONG_PHASE )
    PI_ASSERT( , array, PI_NULL_CHANNEL )
    PI_ASSERT( , size>0, PI_ZERO_MEMBERS )

    PI_CHANNEL **newArray = malloc( sizeof( PI_CHANNEL * ) * size );
    PI_ASSERT( , newArray, PI_MALLOC_ERROR )

    /* create channels with same or reversed endpoints */
    int i;
    PI_PROCESS *from, *to;
    for ( i = 0; i < size; i++ ) {
        PI_ASSERT( LEVEL(1), ISVALID(PI_CHAN,array[i]), PI_INVALID_OBJ )

	from = &thisproc.processes[array[i]->producer];
	to = &thisproc.processes[array[i]->consumer];

	newArray[i] = direction==PI_SAME ?
	    PI_CreateChannel_( from, to ) :
	    PI_CreateChannel_( to, from );
    }
    return newArray;
}

void PI_SetName_(void *object, const char *name)
{
    PI_ON_ERROR_RETURN()
    PI_ASSERT( , thisproc.phase==CONFIG, PI_WRONG_PHASE )
    PI_ASSERT( , object, PI_INVALID_OBJ )

    char *nameField;	 	// points to the object's name array

    /* probe magic number to identify object type */

    if ( ISVALID(PI_PROC,(PI_PROCESS*)object) ) {
	nameField = ((PI_PROCESS*)object)->name;
    }
    else if ( ISVALID(PI_CHAN,(PI_CHANNEL*)object) ) {
	nameField = ((PI_CHANNEL*)object)->name;
    }
    else if ( ISVALID(PI_BUND,(PI_BUNDLE*)object) ) {
	nameField = ((PI_BUNDLE*)object)->name;
    }
    else {
	PI_ASSERT( , 0, PI_INVALID_OBJ )	// can't identify it
    }

    if ( name != NULL )
        strncpy( nameField, name, PI_MAX_NAMELEN );	// make a copy
    else
	strcpy( nameField, "" );	// use empty string if NULL
}

int PI_StartAll_( void )
{
    PI_ON_ERROR_RETURN( 0 )
    PI_ASSERT( , thisproc.phase==CONFIG, PI_WRONG_PHASE )

    thisproc.phase = RUNNING;

    if ( thisproc.rank == 0 ) {

        LOUD printf( PI_BORDER
		     "*** Allocated Pilot processes: %d; channels: %d; bundles: %d\n",
                     thisproc.allocated_processes, thisproc.allocated_channels,
                     thisproc.allocated_bundles );
        int spare = thisproc.worldsize - thisproc.allocated_processes;
        if ( spare > 0 )
            LOUD printf( PI_BORDER
			 "*** Note that --%d-- MPI processes will be idle!\n", spare );
        LOUD printf( "\n\n" );

        /* synchronize on barrier below, now we're done printing */
        MPI_Barrier( MPI_COMM_WORLD );  //// matches barrier below ////

        /* If an online thread needs to be started, create it now */
        if ( OnlineProcess == OLP_THREAD ) {
            PI_ASSERT( ,
                0==pthread_create( &OnlineThreadID, NULL, OnlineThreadFunc, NULL ),
                PI_START_THREAD )
        }

        /* If there is a log file, we have to explicitly send the filename
           length and string.  The online process/thread will be waiting to
           receive this.  (An online thread could get it out of this node's
           address space, but we still send it for consistency.)
        */
        if ( OnlineProcess != OLP_NONE ) {
            int flen = LogFilename ? strlen(LogFilename)+1 : 0;
            PI_CALLMPI( MPI_Send( &flen, 1, MPI_INT,
                              thisproc.svc_flag[OLP_RANK], 0, MPI_COMM_WORLD ) )
            if ( flen ) {
                PI_CALLMPI( MPI_Send( LogFilename, flen, MPI_CHAR,
                              thisproc.svc_flag[OLP_RANK], 0, MPI_COMM_WORLD ) )
            }
        }

        return 0;
        /* continues executing main(), the master process */
    }

    MPI_Barrier( MPI_COMM_WORLD );  //// matches barrier above ////

    PI_PROCESS *p = &thisproc.processes[thisproc.rank];
    int status = 0;

    if ( p->run ) {
        /* execute function associated with allocated process */

	if ( p->call == 0 )	// C-style call by value
	    status = p->run( p->argument, p->argument2 );

	else 			// Fortran-style call by ref
	    status = ((PI_WORK_FTN)p->run)( &p->argument, &p->argument2 );

    }
    /* if not allocated a process (run==NULL), just fall through */

    /* since we're not the main process, this will normally call exit */
    PI_StopMain_( status );

    /* if we got here, we're a non-main process and Pilot is in "bench
       mode", so return our MPI rank and let the user decide what to do next

       NOTE: now that we have the status arg, should return it instead of rank?
    */
    return thisproc.rank;
}


/* Functions to call after StartAll */


void PI_Write_( PI_CHANNEL *c, const char *format, ... )
{
    PI_ON_ERROR_RETURN()
    PI_ASSERT( , thisproc.phase==RUNNING, PI_WRONG_PHASE )
    PI_ASSERT( , c, PI_NULL_CHANNEL )
    PI_ASSERT( , format, PI_NULL_FORMAT )
    PI_ASSERT( LEVEL(1), ISVALID(PI_CHAN,c), PI_INVALID_OBJ )
    PI_ASSERT( , c->producer==thisproc.rank, PI_ENDPOINT_WRITER )

    int i;
    va_list argptr;
    int mpiArgCount;
    PI_MPI_RTTI mpiArgs[ PI_MAX_FORMATLEN ];

    PI_BUNDLE *b = c->bundle;	// collective bundle associated with channel
    if ( b ) {			// NULL if point-to-point

	/* make sure we're on the rim of the bundled channel */
        PI_ASSERT( LEVEL(1), ISVALID(PI_BUND,b), PI_SYSTEM_ERROR )
	PI_ASSERT( , b->narrow_end==TO, PI_BUNDLED_CHANNEL )
    }

    va_start( argptr, format );
    mpiArgCount = ParseFormatString( IO_CONTEXT_VALS, mpiArgs, format, argptr );
    va_end( argptr );

    for ( i = 0; i < mpiArgCount; i++ ) {
        PI_MPI_RTTI* arg = &mpiArgs[ i ];

        /* Log each item */
        LOGCALL( "Wri", c->chan_id, format, i+1, mpiArgCount )

        if ( b==NULL ) {

	    /* Reduce operation is not valid outside of reducer bundle */
	    PI_ASSERT( , arg->op==MPI_OP_NULL, PI_OP_INVALID )

            PI_CALLMPI( MPISender( arg->buf, arg->count, arg->type, c->consumer,
                                  c->chan_tag, MPI_COMM_WORLD ) )
        }
        else if ( b->usage==PI_GATHER ) {

	    /* Reduce operation is not valid outside of reducer bundle */
	    PI_ASSERT( , arg->op==MPI_OP_NULL, PI_OP_INVALID )

            /* MPI_Gatherv here sends data to consumer process within comm
               communicator (dedicated to this bundle).  In PI_Gather, the
               same MPI_Gatherv receives the data. */
            PI_CALLMPI( MPI_Gatherv(
                            arg->buf, arg->count, arg->type, // what we're sending
                            NULL, NULL, NULL, 0,	// ignored on sender call
                            0, b->comm ) )	// "root" is rank 0 in communicator
        }
	else {	// must be PI_REDUCE

	    PI_ASSERT( , arg->op!=MPI_OP_NULL, PI_OP_MISSING )

            /* First, all members of the communicator participate in the
	       reduction by calling MPI_Reduce. We need a result buffer for this
	       if we are rank 0 in the communicator, i.e., the first channel
	       in the bundle. */
	    MPI_Aint lb, extent;
	    void *resultbuf;

	    if ( c==b->channels[0] ) {
		PI_CALLMPI( MPI_Type_get_extent( arg->type, &lb, &extent ) )
		resultbuf = malloc( extent * arg->count );
		PI_ASSERT( , resultbuf, PI_MALLOC_ERROR )

	    }
	    else resultbuf = NULL;

	    PI_CALLMPI( MPI_Reduce(
			    arg->buf,			// our contribution
			    resultbuf,			// result here if we're "root"
			    arg->count, arg->type,	// what we're sending
			    arg->op,			// the reduce operation
                            0, b->comm ) )	// "root" is rank 0 in communicator

	    /* Next, if our channel is first in the bundle, we have the
	       task of sending the result to the process at the bundle's base. */
	    if ( resultbuf ) {

        	PI_CALLMPI( MPISender( resultbuf, arg->count, arg->type, c->consumer,
                                  c->chan_tag, MPI_COMM_WORLD ) )
		free( resultbuf );
	    }
	}

        c->write_count = c->write_count + 1;
    }
}

void PI_Read_( PI_CHANNEL *c, const char *format, ... )
{
    PI_ON_ERROR_RETURN()
    PI_ASSERT( , thisproc.phase==RUNNING, PI_WRONG_PHASE )
    PI_ASSERT( , c, PI_NULL_CHANNEL )
    PI_ASSERT( , format, PI_NULL_FORMAT )
    PI_ASSERT( LEVEL(1), ISVALID(PI_CHAN,c), PI_INVALID_OBJ )
    PI_ASSERT( , c->consumer==thisproc.rank, PI_ENDPOINT_READER )

    int i;
    va_list argptr;
    int mpiArgCount;
    PI_MPI_RTTI mpiArgs[ PI_MAX_FORMATLEN ];
    MPI_Status status;

    PI_BUNDLE *b = c->bundle;	// collective bundle associated with channel
    if ( b ) {			// NULL if point-to-point

	/* make sure we're on the rim of the bundled channel */
        PI_ASSERT( LEVEL(1), ISVALID(PI_BUND,b), PI_SYSTEM_ERROR )
	PI_ASSERT( , b->narrow_end==FROM, PI_BUNDLED_CHANNEL )
    }

    va_start( argptr, format );
    mpiArgCount = ParseFormatString( IO_CONTEXT_LOCS, mpiArgs, format, argptr );
    va_end( argptr );

    c->write_count++;

    for ( i = 0; i < mpiArgCount; i++ ) {
        PI_MPI_RTTI* arg = &mpiArgs[ i ];

	/* Reduce operation is never valid for PI_Read */
	PI_ASSERT( , arg->op==MPI_OP_NULL, PI_OP_INVALID )

        /* Log each item */
        LOGCALL( "Rea", c->chan_id, format, i+1, mpiArgCount )

        if ( b==NULL ) {

            PI_CALLMPI( MPI_Recv( arg->buf, arg->count, arg->type, c->producer,
                                  c->chan_tag, MPI_COMM_WORLD, &status ) )
        }
        else if ( b->usage==PI_BROADCAST) {

            /* MPI_Bcast here receives data from producer process within comm
               communicator (dedicated to this bundle).  In PI_Broadcast, the
               same MPI_Bcast sends the data. */

            PI_CALLMPI( MPI_Bcast(
                            arg->buf, arg->count, arg->type,	// what we're sending
                            0, b->comm ) )		// "root" is rank 0 in bundle
        }
	else {

            /* MPI_Scatterv here receives data from consumer process within comm
               communicator (dedicated to this bundle).  In PI_Scatter, the
               same MPI_Scatterv receives the data. */
            PI_CALLMPI( MPI_Scatterv(
                            NULL, NULL, NULL, 0,	// ignored on receiver call
                            arg->buf, arg->count, arg->type, // what we're receiving
                            0, b->comm ) )		// "root" is rank 0 in bundle
	}
    }
}

int PI_Select_( PI_BUNDLE *b )
{
    PI_ON_ERROR_RETURN( 0 )
    PI_ASSERT( , thisproc.phase==RUNNING, PI_WRONG_PHASE )
    PI_ASSERT( , b, PI_NULL_BUNDLE )
    PI_ASSERT( LEVEL(1), ISVALID(PI_BUND,b), PI_INVALID_OBJ )
    PI_ASSERT( , b->usage==PI_SELECT, PI_BUNDLE_USAGE )
    PI_ASSERT( , b->narrow_end==TO, PI_ENDPOINT_READER )

    MPI_Status status;
    int i;

    LOGCALL( "Sel", b->bund_id, "", 0, 0 )

    PI_CALLMPI( MPI_Probe( MPI_ANY_SOURCE, b->channels[0]->chan_tag,
                           MPI_COMM_WORLD, &status ) )

    /* note: this is a sequential search! suppose bundle is large?
       May want to build (on the fly) lookup table (hash?) for rank=>index.
       Another alt (since each rank will likely participate in few bundles) is
       to make small lookup table in rank's PI_PROCENVT: [rank].table:tag=>index.
       The table could be PI_MAX_BUNDLES long, and CreateBundle fills in the next entry
       for each producer process.
    */

    for ( i = 0; i < b->size; i++ ) {
        if ( b->channels[i]->producer == status.MPI_SOURCE )
            return i;
    }

    /* If the message source does not match the producer of any of the bundle's
       channels, that's a problem.  PI_ASSERT(, 0, ...) will always abort. */
    PI_ASSERT( , 0, PI_SYSTEM_ERROR )
    return 0;	// never reached, but satisfies compiler
}

int PI_ChannelHasData_( PI_CHANNEL *c )
{
    PI_ON_ERROR_RETURN( 0 )
    PI_ASSERT( , thisproc.phase==RUNNING, PI_WRONG_PHASE )
    PI_ASSERT( , c, PI_NULL_CHANNEL )
    PI_ASSERT( LEVEL(1), ISVALID(PI_CHAN,c), PI_INVALID_OBJ )

    int flag;
    MPI_Status s;

    LOGCALL( "Has", c->chan_id, "", 0, 0 )

    PI_CALLMPI( MPI_Iprobe( c->producer, c->chan_tag, MPI_COMM_WORLD, &flag, &s ) )

    return flag;
}


int PI_TrySelect_( PI_BUNDLE *b )
{
    PI_ON_ERROR_RETURN( -1 )
    PI_ASSERT( , thisproc.phase==RUNNING, PI_WRONG_PHASE )
    PI_ASSERT( , b, PI_NULL_BUNDLE )
    PI_ASSERT( LEVEL(1), ISVALID(PI_BUND,b), PI_INVALID_OBJ )
    PI_ASSERT( , b->usage==PI_SELECT, PI_BUNDLE_USAGE )
    PI_ASSERT( , b->narrow_end==TO, PI_ENDPOINT_READER )

    int flag, i;
    MPI_Status status;

    LOGCALL( "Try", b->bund_id, "", 0, 0 )

    PI_CALLMPI( MPI_Iprobe( MPI_ANY_SOURCE, b->channels[0]->chan_tag,
			    MPI_COMM_WORLD, &flag, &status ) )
    if ( flag == 0 ) return -1;		// no channel has data

    /* lookup message source's corresponding channel index in bundle
       (see comment in PI_Select_ re sequential search) */
    for ( i = 0; i < b->size; i++ ) {
        if ( b->channels[i]->producer == status.MPI_SOURCE )
            return i;
    }

    /* If the message source does not match the producer of any of the bundle's
       channels, that's a problem.  PI_ASSERT(, 0, ...) will always abort. */
    PI_ASSERT( , 0, PI_SYSTEM_ERROR )
    return 0;	// never reached, but satisfies compiler
}

PI_CHANNEL *PI_GetBundleChannel_( const PI_BUNDLE *b, int index )
{
    PI_ON_ERROR_RETURN( NULL )
    PI_ASSERT( , thisproc.phase==RUNNING, PI_WRONG_PHASE )
    PI_ASSERT( , b, PI_NULL_BUNDLE )
    PI_ASSERT( LEVEL(1), ISVALID(PI_BUND,b), PI_INVALID_OBJ )
    PI_ASSERT( , index >= 0 && index < b->size, PI_BUNDLE_INDEX )

    return b->channels[index];
}

int PI_GetBundleSize_( const PI_BUNDLE *b )
{
    PI_ON_ERROR_RETURN( 0 )
    PI_ASSERT( , thisproc.phase==RUNNING, PI_WRONG_PHASE )
    PI_ASSERT( , b, PI_NULL_BUNDLE )
    PI_ASSERT( LEVEL(1), ISVALID(PI_BUND,b), PI_INVALID_OBJ )

    return b->size;
}


void PI_Broadcast_( PI_BUNDLE *b, const char *format, ... )
{
    PI_ON_ERROR_RETURN()
    PI_ASSERT( , thisproc.phase==RUNNING, PI_WRONG_PHASE )
    PI_ASSERT( , b, PI_NULL_BUNDLE )
    PI_ASSERT( , format, PI_NULL_FORMAT )
    PI_ASSERT( LEVEL(1), ISVALID(PI_BUND,b), PI_INVALID_OBJ )
    PI_ASSERT( , b->usage==PI_BROADCAST, PI_BUNDLE_USAGE )
    PI_ASSERT( , thisproc.rank==b->channels[0]->producer, PI_ENDPOINT_WRITER )

    int i;
    va_list argptr;
    int mpiArgCount;
    PI_MPI_RTTI mpiArgs[ PI_MAX_FORMATLEN ];

    va_start( argptr, format );
    mpiArgCount = ParseFormatString( IO_CONTEXT_VALS, mpiArgs, format, argptr );
    va_end( argptr );

    for ( i = 0; i < mpiArgCount; i++ ) {
        PI_MPI_RTTI* arg = &mpiArgs[ i ];

	/* Reduce operation is never valid for PI_Broadcast */
	PI_ASSERT( , arg->op==MPI_OP_NULL, PI_OP_INVALID )

        /* Log each item */
        LOGCALL( "Bro", b->bund_id, format, i+1, mpiArgCount )

        PI_CALLMPI( MPI_Bcast(
                        arg->buf, arg->count, arg->type,	// what we're sending
                        0, b->comm ) )		// "root" is rank 0 in bundle
    }
}


void PI_Scatter_( PI_BUNDLE *b, const char *format, ... )
{
    PI_ON_ERROR_RETURN()
    PI_ASSERT( , thisproc.phase==RUNNING, PI_WRONG_PHASE )
    PI_ASSERT( , b, PI_NULL_BUNDLE )
    PI_ASSERT( , format, PI_NULL_FORMAT )
    PI_ASSERT( LEVEL(1), ISVALID(PI_BUND,b), PI_INVALID_OBJ )
    PI_ASSERT( , b->usage==PI_SCATTER, PI_BUNDLE_USAGE )
    PI_ASSERT( , thisproc.rank==b->channels[0]->producer, PI_ENDPOINT_WRITER )

    int i, chan;
    va_list argptr;
    int mpiArgCount;
    PI_MPI_RTTI mpiArgs[ PI_MAX_FORMATLEN ];

    va_start( argptr, format );
    mpiArgCount = ParseFormatString( IO_CONTEXT_LOCS, mpiArgs, format, argptr );
    va_end( argptr );

    for ( i = 0; i < mpiArgCount; i++ ) {
        PI_MPI_RTTI* arg = &mpiArgs[ i ];

	/* Reduce operation is never valid for PI_Scatter */
	PI_ASSERT( , arg->op==MPI_OP_NULL, PI_OP_INVALID )

        /* set up args for MPI_Scatter (sending side) */
        int sendcounts[b->size+1];	// count sent to each process
        int displs[b->size+1];		// displacements in userbuf for send

        /* Log each item */
        LOGCALL( "Sca", b->bund_id, format, i+1, mpiArgCount )

        /* prepare sendcounts and displs arrays so that root receives nothing,
           and all the rest receive 'count' items */
        sendcounts[0] = displs[0] = 0;
        for ( chan=1; chan<=b->size; chan++ ) {
            sendcounts[chan] = arg->count;
            displs[chan] = (chan-1) * arg->count;	// fits buffer of size*count items
        }

#ifdef MPI_IN_PLACE
        PI_CALLMPI( MPI_Scatterv(
                        arg->buf, sendcounts, displs, arg->type,	// sends all data
                        MPI_IN_PLACE, 0, 0,	// receive 0 data from "root"
                        0, b->comm ) )		// "root" is P0 in bundle communicator
#else
        char recvbuf[1];	// root receives 0-length data, so make dummy
        PI_CALLMPI( MPI_Scatterv(
                        arg->buf, sendcounts, displs, arg->type,	// sends all data
                        recvbuf, 0, arg->type,	// receive 0 data from "root"
                        0, b->comm ) )		// "root" is P0 in bundle communicator
#endif
    }
}


void PI_Reduce_( PI_BUNDLE *b, const char *format, ... )
{
    PI_ON_ERROR_RETURN()
    PI_ASSERT( , thisproc.phase==RUNNING, PI_WRONG_PHASE )
    PI_ASSERT( , b, PI_NULL_BUNDLE )
    PI_ASSERT( , format, PI_NULL_FORMAT )
    PI_ASSERT( LEVEL(1), ISVALID(PI_BUND,b), PI_INVALID_OBJ )
    PI_ASSERT( , b->usage==PI_REDUCE, PI_BUNDLE_USAGE )
    PI_ASSERT( , thisproc.rank==b->channels[0]->consumer, PI_ENDPOINT_READER )

    int i;
    va_list argptr;
    int mpiArgCount;
    PI_MPI_RTTI mpiArgs[ PI_MAX_FORMATLEN ];
    MPI_Status status;

    va_start( argptr, format );
    mpiArgCount = ParseFormatString( IO_CONTEXT_LOCS, mpiArgs, format, argptr );
    va_end( argptr );

    for ( i = 0; i < mpiArgCount; i++ ) {
        PI_MPI_RTTI* arg = &mpiArgs[ i ];

	/* PI_Reduce doesn't actually use the operator, but we insist on it
	   for consistency. */
	PI_ASSERT( , arg->op!=MPI_OP_NULL, PI_OP_MISSING )

        /* Log each item */
        LOGCALL( "Rdu", b->bund_id, format, i+1, mpiArgCount )

	/* The actual reduction is done within the communicator, i.e., by the
	   processes on the bundle's rim.  The 1st channel's producer process
	   will send the result back here. */
        PI_CALLMPI( MPI_Recv( arg->buf, arg->count, arg->type,
			b->channels[0]->producer, b->channels[0]->chan_tag,
			MPI_COMM_WORLD, &status ) )
    }
}


void PI_Gather_( PI_BUNDLE *b, const char *format, ... )
{
    PI_ON_ERROR_RETURN()
    PI_ASSERT( , thisproc.phase==RUNNING, PI_WRONG_PHASE )
    PI_ASSERT( , b, PI_NULL_BUNDLE )
    PI_ASSERT( , format, PI_NULL_FORMAT )
    PI_ASSERT( LEVEL(1), ISVALID(PI_BUND,b), PI_INVALID_OBJ )
    PI_ASSERT( , b->usage==PI_GATHER, PI_BUNDLE_USAGE )
    PI_ASSERT( , thisproc.rank==b->channels[0]->consumer, PI_ENDPOINT_READER )

    int i, chan;
    va_list argptr;
    int mpiArgCount;
    PI_MPI_RTTI mpiArgs[ PI_MAX_FORMATLEN ];

    va_start( argptr, format );
    mpiArgCount = ParseFormatString( IO_CONTEXT_LOCS, mpiArgs, format, argptr );
    va_end( argptr );

    for ( i = 0; i < mpiArgCount; i++ ) {
        PI_MPI_RTTI* arg = &mpiArgs[ i ];

	/* Reduce operation is never valid for PI_Gather */
	PI_ASSERT( , arg->op==MPI_OP_NULL, PI_OP_INVALID )

        /* set up args for MPI_Gather (receiving side) */
        int recvcounts[b->size+1];	// count that each process sends
        int displs[b->size+1];		// displacements in userbuf for recv

        /* Log each item */
        LOGCALL( "Gat", b->bund_id, format, i+1, mpiArgCount )

        /* prepare recvcounts and displs arrays so that root sends nothing,
           and all the rest send 'count' items */
        recvcounts[0] = displs[0] = 0;
        for ( chan=1; chan<=b->size; chan++ ) {
            recvcounts[chan] = arg->count;
            displs[chan] = (chan-1) * arg->count;	// fits buffer of size*count items
        }

#ifdef MPI_IN_PLACE
        PI_CALLMPI( MPI_Gatherv(
                        MPI_IN_PLACE, 0, 0,	// send no data from "root"
                        arg->buf, recvcounts, displs, arg->type,	// receives all data
                        0, b->comm ) )		// "root" is P0 in bundle communicator
#else
        char sendbuf[1];	// root sends 0-length data, so make dummy
        PI_CALLMPI( MPI_Gatherv(
                        sendbuf, 0, arg->type,	// send 0 data from "root"
                        arg->buf, recvcounts, displs, arg->type,	// receives all data
                        0, b->comm ) )		// "root" is P0 in bundle communicator
#endif
    }
}


void PI_Log_( const char *text )
{
    PI_ON_ERROR_RETURN()
    PI_ASSERT( , thisproc.phase==RUNNING, PI_WRONG_PHASE )

    /* if logging to file enabled, forward to LogEvent as USER type event */
    if ( thisproc.svc_flag[OLP_LOGFILE] ) LogEvent( USER, text );
}


/* This function might be called before Pilot's tables are all set up, so be
   sure we don't deref. any NULL pointers.  It can be called in any phase of
   the program by any process.  If MPI is not even running yet, it will call
   abort() and get out that way.  If Pilot is in the configuration phase (where
   the same code is running on all nodes), only rank 0 will print, to avoid
   cluttering the display with many duplicate messages.
*/
void PI_Abort( const int errcode, const char *text, const char *file, const int line )
{
    if ( thisproc.phase != CONFIG || thisproc.rank == 0 ) {
	char *procname = "";
	int procarg = 0;
	if ( thisproc.processes ) {
            procname = thisproc.processes[thisproc.rank].name;
            procarg = thisproc.processes[thisproc.rank].argument;
	}
    	fprintf( stderr, "\n" PI_BORDER
		"*** PI_Abort *** Called from MPI process #%d = Pilot process:\n"
		PI_BORDER "***   %s(%d) @ %s:%d:\n"
		PI_BORDER "***   %s%s\n" PI_BORDER
		"The above should pinpoint the problem.\n" PI_BORDER
		"Subsequent messages from MPI can likely be disregarded.\n",
             thisproc.rank, procname, procarg, file, line,
             ( errcode >= PI_MIN_ERROR && errcode <= PI_MAX_ERROR ) ?
             ErrorText[errcode] : "",
             text ? text : "" );
    }

    /* MPI should shut down the application and may call exit/abort(errcode) */
    int MPI_up;
    MPI_Initialized( &MPI_up );
    if ( MPI_up )
        MPI_Abort( MPI_COMM_WORLD, errcode );
    else
        abort();
    /******** does not return *********/
}

void PI_StopMain_( int status )
{
    PI_ON_ERROR_RETURN()
    PI_ASSERT( , thisproc.phase==RUNNING, PI_WRONG_PHASE )

    int i /***********, j**********/ ;

    /* First job is to shutdown logging, if it's active. */
    if ( thisproc.svc_flag[LOGGING] ) {

	/* Notify log that this process is finished (unless this *is* the log
	   process on rank 1) */
	if ( thisproc.rank != 1 || thisproc.svc_flag[OLP_RANK] != 1 ) {
	    char buff[PI_MAX_LOGLEN];
	    sprintf( buff, "FIN" PI_LOGSEP "%d", status );
            LogEvent( PILOT, buff );
	}

	/* If online thread was running (on rank 0), join with it */
        if ( thisproc.rank == 0 && thisproc.svc_flag[OLP_RANK] == 0 )
            pthread_join( OnlineThreadID, NULL );
    }

    MPI_Barrier( MPI_COMM_WORLD );	/* synchronize all processes */

    /* If user pre-initialized MPI, then leave it initialized.  This is to
       allow Pilot to be re-configured and used again in this program, which is
       needed for running benchmarks, but not in ordinary use.
    */
    if ( MPIPreInit )
        thisproc.phase = PREINIT;
    else {
        thisproc.phase = POSTRUN;
        MPI_Finalize( );
    }

    /* deallocate memory */

    for ( i = 0; i < thisproc.allocated_channels; i++ )
	free( thisproc.channels[i] );

    if ( thisproc.channels != NULL )
        free( thisproc.channels );

    if ( thisproc.processes != NULL )
        free( thisproc.processes );

    if ( thisproc.bundles != NULL )
        free( thisproc.bundles );

    /* The main process always returns, but other processes normally exit
       here because otherwise they would return from PI_StartAll and (re)execute
       main's code.  However, if Pilot is in "bench mode", we do return so
       that another Pilot application can be configured and executed.
    */
    if ( thisproc.rank!=0 && !MPIPreInit ) exit( 0 );
}


/*** Internal Functions ***/


/********* want a function that investigates what "reasonable" values are for
 pointers on this platform.  It should check static, stack, & malloc'd addrs,
 and come up with min/max ranges for valid pointers (as opposed to data).  This
 is for use in PI_Read where user must remember to code "&".  Since the "figuring
 out" may be inaccurate on a given platform, the check should occur at Level 2,
 only if the user wants.  So the function calculates the range, then a macro
 ISPTR(p) checks it.  Even if this is dreaming, we can at least check for NULL.
**********/

/*!
********************************************************************************
Called by MPI to handle error in library function.
Handle the error reported from MPI by printing message and aborting.
Could be due to Pilot's misuse of MPI, or MPI detecting a user error (like
mismatched read/write data types or lengths).

\param comm MPI communicator where error occurred (will be MPI_COMM_WORLD).
\param code MPI error code
\param ... additional implementation-specific args (ignore)
*******************************************************************************/
static void HandleMPIErrors( MPI_Comm *comm, int *code, ... )
{
    char buff[MPI_MAX_ERROR_STRING], text[MPI_MAX_ERROR_STRING+80];
    int len;

    MPI_Error_string( *code, buff, &len );	// obtain text for error code

    snprintf( text, sizeof(text), " at " __FILE__ ":%d; MPI error code %d:\n%s",
              MPICallLine, *code, buff );

    PI_Abort( PI_MPI_ERROR, text, PI_CallerFile, PI_CallerLine );
    /***** does not return *****/
}

/*!
********************************************************************************
Parse command-line arguments to Pilot. Fills in #Option.
*******************************************************************************/
static char *ParseArgs( int *argc, char ***argv )
{
    int i, j, unrec, count=0, moveto=0;
    char *badargs = NULL;		// assume all -pi... args will be OK

    memset( Option, 0, OPT_END );	// clear all option flags
    LogFilename = NULL;			// assume no log needed
    OnlineProcess = OLP_NONE;		// assume no online process needed

    /* scan args, shuffling non-Pilot args up in *argv array */
    for ( i=0; i<*argc; i++ ) {
        unrec = 0;
        if ( 0==strncmp( (*argv)[i], "-pi", 3 ) ) {	// -pi... arg found

            /* '-pisvc=...' runtime services */
            if ( 0==strncmp( (*argv)[i]+3, "svc=", 4 ) ) {
                for ( j=7; (*argv)[i][j]; j++ ) {
                    switch ( toupper( (*argv)[i][j] ) ) {
                    case 'C':
                        Option[OPT_CALLS] = 1;
                        break;
                    case 'S':
                        Option[OPT_STATS] = 1;
                        break;
                    case 'M':
                        Option[OPT_TOPO] = 1;
                        break;
                    case 'T':
                        Option[OPT_TRACE] = 1;
                        break;
                    case 'D':
                        Option[OPT_DEADLOCK] = 1;
                        break;
                    default:
                        unrec = 1;
                    }
                }
            }

            /* '-pilog=t|p =filename =t|p:filename' */
            else if ( 0==strncmp( (*argv)[i]+3, "log=", 4 ) ) {
                char tp = (char)toupper( (*argv)[i][7] ); // possible t or p flag
                int len = strlen( (*argv)[i] );
                if ( len < 8 ) unrec = 1;
                else if ( len == 8 ) {
                    if ( 'T'==tp || 'P'==tp )
                        OnlineProcess = 'T'==tp ? OLP_THREAD : OLP_PILOT;
                    else LogFilename = (*argv)[i]+7; // found 1-char filename
                }
                else if ( ':'==(*argv)[i][8] ) {
                    if ( 'T'==tp || 'P'==tp )
                        OnlineProcess = 'T'==tp ? OLP_THREAD : OLP_PILOT;
                    else unrec = 1;
                    if ( len > 9 )
                        LogFilename = (*argv)[i]+9;	// found :filename
                }
                else LogFilename = (*argv)[i]+7;	// found filename
            }

            /* '-picheck=n' */
            else if ( 0==strncmp( (*argv)[i]+3, "check=", 6 ) ) {
                if ( 10==strlen( (*argv)[i] ) ) {
                    j = (*argv)[i][9];	// extract level number
                    if ( isdigit(j) ) PI_CheckLevel = j - '0';
                    else unrec = 1;
                }
                else unrec = 1;
            }

            else unrec = 1;

            /* save up all unrecognized arguments to return to caller */
            if ( unrec ) {
                j = badargs ? strlen(badargs) : 0;	// current string len
                badargs = realloc( badargs, j + strlen((*argv)[i]) + 1 );
                strcpy( badargs+j, " " );
                strcpy( badargs+j+1, (*argv)[i] );
            }
        }
        else {
            if ( count < i ) (*argv)[moveto] = (*argv)[i];
            count++;
            moveto++;
        }
    }
    *argc = count;	// adjust remaining arg count

    return badargs;
}


/*!
********************************************************************************
This thread is used to invoke OnlineProcessFunc when the latter has to run
as a thread on node 0.
*******************************************************************************/
static void *OnlineThreadFunc( void *arg )
{
    OnlineProcessFunc( 0, NULL );
    return NULL;    // thread will be joined by PI_StopMain
}


/*!
********************************************************************************
This process handles collecting/printing log entries, and running any other
online services such as deadlock detection.  The log filename, if any,
is received from PI_MAIN.

Currently, the log timestamp is being added here. MPI semantics guarantee
that the events from any given process will be logged in order, but there
is no guarantee of a total ordering of all events from all processes. It
would be more accurate to have PI_Log timestamp the event on its own node,
then have this function apply a correction, like how MPE tries to synchronize
all the clocks.

\note If the program crashes, log entries -- maybe the entire file -- may be
lost in OS buffers. We should probably do some selective periodic flushing,
but not every line to avoid burdening the program with disk activity.
*******************************************************************************/
static int OnlineProcessFunc( int dum1, void *dum2 )
{
    MPI_Status stat;
    int flen;
    char *fname;
    FILE *logfile = NULL;
    char buff[PI_MAX_LOGLEN];

    double start = MPI_Wtime();     // capture time at start of run

    /* get filename length; 0 = no log file */
    PI_CALLMPI( MPI_Recv( &flen, 1, MPI_INT, PI_MAIN, 0, MPI_COMM_WORLD, &stat ) )

    /* open the log file if needed */
    if ( flen ) {
        PI_OLP_ASSERT( fname = malloc( flen ), PI_MALLOC_ERROR )
        PI_CALLMPI( MPI_Recv( fname, flen, MPI_CHAR,
                              PI_MAIN, 0, MPI_COMM_WORLD, &stat ) )
        logfile = fopen( fname, "w" );
        if ( NULL==logfile )
            PI_Abort( PI_LOG_OPEN, fname, __FILE__, __LINE__  );
        /***** does not return *****/

        free( fname );
    }

    if ( thisproc.svc_flag[LOG_TABLES] );   // dump tables to log file
    // might be easier to do in PI_MAIN with calls to LogEvent

    /* startup other OLPs */
    if ( thisproc.svc_flag[OLP_DEADLOCK] ) PI_DetectDL_start_( &thisproc );


    /******** main loop till "FIN" messages ********/

    /* no. of FINs that have to check in (1 less if we are Pilot process) */
    int FINs = thisproc.worldsize - thisproc.svc_flag[OLP_RANK];
    while ( FINs > 0 ) {
        /* wait for next message from LogEvent */
        PI_CALLMPI( MPI_Recv( buff, PI_MAX_LOGLEN, MPI_CHAR,
                              MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &stat ) )

        char *event = buff;
        int contchar = PI_MAX_LOGLEN - 1;   // index of continuation char
        int source = stat.MPI_SOURCE;

        /* receive rest of message while continuation char found */
        while ( event[contchar] == '+' ) {
            if ( event == buff )            // first extension
                event = strdup( buff );     // get msg in dynamic storage
            int msglen = strlen( event );
            PI_OLP_ASSERT( event = realloc( event, msglen+PI_MAX_LOGLEN ),
                            PI_MALLOC_ERROR )   // extend buffer

            /* continue receiving just from source of partial message */
            PI_CALLMPI( MPI_Recv( event+msglen, PI_MAX_LOGLEN, MPI_CHAR,
                              source, 0, MPI_COMM_WORLD, &stat ) )
            contchar = msglen + PI_MAX_LOGLEN - 1;
        }

        /* forward to OLP if event type is one it wants */
        if ( thisproc.svc_flag[OLP_DEADLOCK] )
            if ( event[0] == PILOT || event[0] == CALLS )
                PI_DetectDL_event_( event );

        /* get timestamp (nsec from start) and write event to log file */
        if ( logfile )
            fprintf( logfile, "%.6ld" PI_LOGSEP "%s\n",
                        (long int)((MPI_Wtime()-start)*1000000), event );

        /* check for "P_n_FIN" pattern, where P is the PILOT message type char,
            _ is the separator, and n is the process number.  We need to get
           one from all processes, so decrement counter.
        */
        if ( event[0] == PILOT ) {
            char *sep = strpbrk( event+2, PI_LOGSEP );   // skip over P_n
            if ( sep && 0==strncmp( sep+1, "FIN", 3 ) ) FINs--;
        }

        if ( event != buff ) free( event ); // it was malloc'd
    }

    /* terminate OLPs */
    if ( thisproc.svc_flag[OLP_DEADLOCK] ) PI_DetectDL_end_();

    if ( thisproc.svc_flag[LOG_STATS] );    // TODO dump stats to log file
    // who collects the stats?

    if ( logfile ) fclose( logfile );

    return 0;
}


/*!
********************************************************************************
Add process number and send to online process.  Format of fixed len message:

 		Pn_t_event...c

  - Pn is the process no. (rank)	<- can't sort this w/o leading 0's
  - _ is the field separator PI_LOGSEP
  - t is the numeric log event type
  - event is as much of the text as will fit, leaving room for \\0
  - c is the continuation character '+' or space for last line

Overflow will only be an issue with user events (via PI_Log).
Rank of OLP is in svc_flag[OLP_RANK]. We use tag=0 since it is not assigned
for channels.
\note This can probably be improved with non-blocking sends (for the last
line), but then the function won't be reentrant (which probably doesn't
matter).
*******************************************************************************/
static void LogEvent( LOGEVENT ev, const char *event )
{
    char buff[PI_MAX_LOGLEN];
    int len = snprintf( buff, PI_MAX_LOGLEN-1,
                        "%c" PI_LOGSEP "%d" PI_LOGSEP "%s",
                        (char)ev, thisproc.rank, event );

    /* len >= LOGLEN-1 means that overflow bytes remain in event, so send another
       line starting from that point */
    const char *next =
            event + PI_MAX_LOGLEN-2 - (strpbrk( buff+2, PI_LOGSEP )-buff+1);

    while ( len >= PI_MAX_LOGLEN-1 ) {
        buff[PI_MAX_LOGLEN-1] = '+';	// insert continuation character

        PI_CALLMPI( MPI_Send( buff, PI_MAX_LOGLEN, MPI_CHAR,
                              thisproc.svc_flag[OLP_RANK], 0, MPI_COMM_WORLD ) )

        len = snprintf( buff, PI_MAX_LOGLEN-1, "%s", next );
        next = next + PI_MAX_LOGLEN-2;
    }
    buff[PI_MAX_LOGLEN-1] = ' ';    // indicate last line

    PI_CALLMPI( MPI_Send( buff, PI_MAX_LOGLEN, MPI_CHAR,
                          thisproc.svc_flag[OLP_RANK], 0, MPI_COMM_WORLD ) )
}

/* -------- Format String Parsing -------- */

/*! Use this enum to help mapping between C datatypes and MPI datatypes.
MPI datatypes are not guaranteed to be integer constants. Note that since
Fortran Read/Write is always from/to an address, actual data values are
never supplied in the arg list and therefore no type-specific processesing
is ever needed. */
typedef enum {
    CTYPE_INVALID = -1,
    CTYPE_CHAR,
    CTYPE_SHORT,
    CTYPE_INT,
    CTYPE_LONG,
    CTYPE_UNSIGNED_CHAR,
    CTYPE_UNSIGNED_SHORT,
    CTYPE_UNSIGNED_LONG,
    CTYPE_UNSIGNED,
    CTYPE_FLOAT,
    CTYPE_DOUBLE,
    CTYPE_LONG_DOUBLE,
    CTYPE_BYTE,
    CTYPE_LONG_LONG,
    CTYPE_UNSIGNED_LONG_LONG,
    CTYPE_FORTRAN,
    CTYPE_USER_DEFINED
} CTYPE;

/*!
********************************************************************************
Stores the first three alphanumeric chars of \p bytes into an integer. This
provides O(1) lookup time for the conversion specifiers. It is case sensitive.

\post Bits 0 - 23 of the return value contain the 3 chars.
*******************************************************************************/
static int32_t BytesToInt( const char *bytes )
{
    int32_t result = 0;
    int i = 0;
    while ( i < 3 && isalnum( bytes[ i ] ) ) {
        result |= ( bytes[ i ] & 0xff ) << ( 16 - i * 8 );
        i += 1;
    }
    return result;
}

/*!
********************************************************************************
Stores the first \p len chars of \p bytes into an integer. This provides O(1)
lookup time for the reduce operators. It is case sensitive.

\pre len should be in the range 1-3
\post Bits 0 - 23 of the return value contain the 1-3 chars.
*******************************************************************************/
static int32_t OpToInt( int len, const char *bytes )
{
    int32_t result = 0;
    int i = 0;
    while ( i < len ) {
        result |= ( bytes[ i ] & 0xff ) << ( 16 - i * 8 );
        i += 1;
    }
    return result;
}

/*!
********************************************************************************
Check whether there are more arguments in the varargs by probing for the sentinels.

\param ap  The va_list to read the arguments from. This function uses the
va_arg macro on a copy of the list, so it is non-destructive to the state of ap.
\return True if there is at least one more arguments; false if the sentinels were found.
*******************************************************************************
static int MoreArgs( va_list ap )
{
    va_list args;
    va_copy( args, ap );

    if ( PI_END1==va_arg( args, int ) )
	if ( PI_END2==va_arg( args, int ) )
	    return 0;
    return 1;
} */

/*!
********************************************************************************
Fills in \c rtti->type and \c rtti->cType given a conversion specification.

\return The number of characters that have been successfully processed.
\retval 0 indicates failure since conversion specifiers are at least one
char long.
*******************************************************************************/
static int LookupConversionSpec( const char *key, PI_MPI_RTTI *rtti )
{
    CTYPE cType = CTYPE_INVALID;
    MPI_Datatype mpiType = MPI_DATATYPE_NULL;
    int skip = 0;

// Easy-ish way to define a conversion specifier.
#define CONVERSION_SPEC( c1, c2, c3 ) \
    ( ( (c1) & 0xff ) << 16 | ( (c2) & 0xff ) << 8 | ( (c3) & 0xff ) )

    switch ( BytesToInt( key ) ) {
    case CONVERSION_SPEC( 'b', 0, 0 ):
        cType = CTYPE_BYTE;
        mpiType = MPI_BYTE;
        skip = 1;
        break;

    case CONVERSION_SPEC( 'c', 0, 0 ):
        cType = CTYPE_CHAR;
        mpiType = MPI_CHAR;
        skip = 1;
        break;

    case CONVERSION_SPEC( 'h', 'd', 0 ):
    case CONVERSION_SPEC( 'h', 'i', 0 ):
        cType = CTYPE_SHORT;
        mpiType = MPI_SHORT;
        skip = 2;
        break;

    case CONVERSION_SPEC( 'd', 0, 0 ):
    case CONVERSION_SPEC( 'i', 0, 0 ):
        cType = CTYPE_INT;
        mpiType = MPI_INT;
        skip = 1;
        break;

    case CONVERSION_SPEC( 'l', 'd', 0 ):
    case CONVERSION_SPEC( 'l', 'i', 0 ):
        cType = CTYPE_LONG;
        mpiType = MPI_LONG;
        skip = 2;
        break;

    case CONVERSION_SPEC( 'l', 'l', 'd' ):
    case CONVERSION_SPEC( 'l', 'l', 'i' ):
        cType = CTYPE_LONG_LONG;
        mpiType = MPI_LONG_LONG;
        skip = 3;
        break;

    case CONVERSION_SPEC( 'h', 'h', 'u' ):
        cType = CTYPE_UNSIGNED_CHAR;
        mpiType = MPI_UNSIGNED_CHAR;
        skip = 3;
        break;

    case CONVERSION_SPEC( 'h', 'u', 0 ):
        cType = CTYPE_UNSIGNED_SHORT;
        mpiType = MPI_UNSIGNED_SHORT;
        skip = 2;
        break;

    case CONVERSION_SPEC( 'u', 0, 0 ):
        cType = CTYPE_UNSIGNED;
        mpiType = MPI_UNSIGNED;
        skip = 1;
        break;

    case CONVERSION_SPEC( 'l', 'u', 0 ):
        cType = CTYPE_UNSIGNED_LONG;
        mpiType = MPI_UNSIGNED_LONG;
        skip = 2;
        break;

    case CONVERSION_SPEC( 'l', 'l', 'u' ):
        cType = CTYPE_UNSIGNED_LONG_LONG;
        mpiType = MPI_UNSIGNED_LONG_LONG;
        skip = 3;
        break;

    case CONVERSION_SPEC( 'f', 0, 0 ):
        cType = CTYPE_FLOAT;
        mpiType = MPI_FLOAT;
        skip = 1;
        break;

    case CONVERSION_SPEC( 'l', 'f', 0 ):
        cType = CTYPE_DOUBLE;
        mpiType = MPI_DOUBLE;
        skip = 2;
        break;

    case CONVERSION_SPEC( 'L', 'f', 0 ):
        cType = CTYPE_LONG_DOUBLE;
        mpiType = MPI_LONG_DOUBLE;
        skip = 2;
        break;

    case CONVERSION_SPEC( 'm', 0, 0 ):
        cType = CTYPE_USER_DEFINED;
        /* Let the caller fill in the MPI_Datatype */
        skip = 1;
        break;

	// Fortran types start with 'F' (suppress if symbols not defined)

#ifndef MPID_NO_FORTRAN

	/* HP MPI only supplies MPI_xxx symbols for a handful of "C usable"
	   Fortran types. Follow their model in mpi.h to define the missing
	   symbols. */

#ifdef HP_MPI
#define MPI_INTEGER1             ((MPI_Datatype) MPI_Type_f2c(MPIF_INTEGER1))
#define MPI_INTEGER2             ((MPI_Datatype) MPI_Type_f2c(MPIF_INTEGER2))
#define MPI_INTEGER4             ((MPI_Datatype) MPI_Type_f2c(MPIF_INTEGER4))
#define MPI_REAL4                ((MPI_Datatype) MPI_Type_f2c(MPIF_REAL4))
#define MPI_REAL8                ((MPI_Datatype) MPI_Type_f2c(MPIF_REAL8))


	/* There are still two "newly added datatypes" only found in mpif.h.
	   Ideally, these should be extracted from mpif.h by "configure" when
	   Pilot is installed with a given MPI lib, in case they change.

	       parameter (MPI_INTEGER8=36)
	       parameter (MPI_REAL16=37)
	*/

#define MPI_INTEGER8             ((MPI_Datatype) MPI_Type_f2c(36))
#define MPI_REAL16               ((MPI_Datatype) MPI_Type_f2c(37))
#endif

    case CONVERSION_SPEC( 'F', 'c', 0 ):
        cType = CTYPE_FORTRAN;
        mpiType = MPI_CHARACTER;
        skip = 2;
        break;

    case CONVERSION_SPEC( 'F', 'i', 0 ):
        cType = CTYPE_FORTRAN;
        mpiType = MPI_INTEGER;
        skip = 2;
        break;

    case CONVERSION_SPEC( 'F', 'i', '1' ):
        cType = CTYPE_FORTRAN;
        mpiType = MPI_INTEGER1;
        skip = 3;
        break;

    case CONVERSION_SPEC( 'F', 'i', '2' ):
        cType = CTYPE_FORTRAN;
        mpiType = MPI_INTEGER2;
        skip = 3;
        break;

    case CONVERSION_SPEC( 'F', 'i', '4' ):
        cType = CTYPE_FORTRAN;
        mpiType = MPI_INTEGER4;
        skip = 3;
        break;

    case CONVERSION_SPEC( 'F', 'i', '8' ):
        cType = CTYPE_FORTRAN;
        mpiType = MPI_INTEGER8;
        skip = 3;
        break;

    case CONVERSION_SPEC( 'F', 'r', 0 ):
        cType = CTYPE_FORTRAN;
        mpiType = MPI_REAL;
        skip = 2;
        break;

    case CONVERSION_SPEC( 'F', 'r', '4' ):
        cType = CTYPE_FORTRAN;
        mpiType = MPI_REAL4;
        skip = 3;
        break;

    case CONVERSION_SPEC( 'F', 'r', '8' ):
        cType = CTYPE_FORTRAN;
        mpiType = MPI_REAL8;
        skip = 3;
        break;

    case CONVERSION_SPEC( 'F', 'r', '6' ):
        cType = CTYPE_FORTRAN;
        mpiType = MPI_REAL16;
        skip = 3;
        break;

    case CONVERSION_SPEC( 'F', 'd', 'p' ):
        cType = CTYPE_FORTRAN;
        mpiType = MPI_DOUBLE_PRECISION;
        skip = 3;
        break;
#endif

    default:
        return 0;
    }

    if ( rtti ) {
        rtti->cType = cType;
        rtti->type = mpiType;
    }

    return skip;
}

/*!
********************************************************************************
Fills in \c rtti->op given a reduce operator in the first \p len bytes of \p key.
If op is MPI_OP_NULL but the return value is non-0, then the caller should obtain
a user-defined operator.

\return The number of characters that have been successfully processed.
\retval 0 indicates failure since reduce operators are at least one
char long.
*******************************************************************************/
static int LookupReduceOp( int len, const char *key, PI_MPI_RTTI *rtti )
{
    MPI_Op mpiOp = MPI_OP_NULL;
    int skip = 0;

// Easy-ish way to define an operator.
#define REDUCE_OP CONVERSION_SPEC

    switch ( OpToInt( len, key ) ) {
    case REDUCE_OP( 'm', 'i', 'n' ):
        mpiOp = MPI_MIN;
        skip = 3;
        break;

    case REDUCE_OP( 'm', 'a', 'x' ):
        mpiOp = MPI_MAX;
        skip = 3;
        break;

    case REDUCE_OP( '+', 0, 0 ):
        mpiOp = MPI_SUM;
        skip = 1;
        break;

    case REDUCE_OP( '*', 0, 0 ):
        mpiOp = MPI_PROD;
        skip = 1;
        break;

    case REDUCE_OP( '&', '&', 0 ):
        mpiOp = MPI_LAND;
        skip = 2;
        break;

    case REDUCE_OP( '|', '|', 0 ):
        mpiOp = MPI_LOR;
        skip = 2;
        break;

    case REDUCE_OP( '^', '^', 0 ):
        mpiOp = MPI_LXOR;
        skip = 2;
        break;

    case REDUCE_OP( '&', 0, 0 ):
        mpiOp = MPI_BAND;
        skip = 1;
        break;

    case REDUCE_OP( '|', 0, 0 ):
        mpiOp = MPI_BOR;
        skip = 1;
        break;

    case REDUCE_OP( '^', 0, 0 ):
        mpiOp = MPI_BXOR;
        skip = 1;
        break;

    case REDUCE_OP( 'm', 'o', 'p' ):
	/* let caller fill in user-defined operator */
        skip = 3;
        break;

    default:
        return 0;
    }

    if ( rtti ) {
        rtti->op = mpiOp;
    }

    return skip;
}


/*!
********************************************************************************
Parse a printf like format string into data which describes MPI data.

\param valsOrLocs  Whether the va_list should be interpreted as a list of
values (e.g., PI_Write) or locations (e.g., PI_Read). Locations are demanded for
certain collective output functions that draw from arrays (PI_Scatter). If values
are allowed, locations can still be distinguished by coding a length.
\param meta  An array of size PI_MAX_FORMATLEN to hold the parsed arguments.
\param fmt  Printf like format to be parsed.
\param ap  The va_list to read the arguments from. This function uses the
va_arg macro, so the value of `ap` is undefined after the call. This
function does not call va_end. See stdarg(3).

\return The number of arguments parsed or -1 when an invalid format string
is encountered.
*******************************************************************************/
static int ParseFormatString( IO_CONTEXT valsOrLocs, PI_MPI_RTTI meta[],
                              const char *fmt, va_list ap )
{
    const char *s = fmt;
    int metaIndex;

    PI_ON_ERROR_RETURN( -1 );
    PI_ASSERT( , fmt != NULL, PI_NULL_FORMAT );

    for ( metaIndex = 0; metaIndex < PI_MAX_FORMATLEN; metaIndex++ ) {
        PI_MPI_RTTI *rtti = &meta[ metaIndex ];
        int count = -1; /* -1 for not user specified */

        /* Skip whitespace in fmt */
        while ( isspace(*s) ) s++;

        if ( *s == '\0' )
            break;

        /* The next char must mark the start of a conversion specification. */
        PI_ASSERT( , *s == '%', PI_FORMAT_INVALID );

        s++;
        PI_ASSERT( , *s != '\0', PI_FORMAT_INVALID );

	/* Parse optional reduce operation */
	char *slash = strchr( s , '/' );	// look for slash
	if ( slash ) {
	    int oplen = slash - s;		// op should be 1-3 chars
	    PI_ASSERT( , oplen>=1 || oplen<=3, PI_FORMAT_INVALID );

            /* Figure out which MPI op to use */
            int skip = LookupReduceOp( oplen, s, rtti );
            PI_ASSERT( , skip > 0, PI_FORMAT_INVALID );

	    /* Obtain user-defined operator from next arg */
	    if ( rtti->op == MPI_OP_NULL ) {
////		PI_ASSERT( LEVEL(2), MoreArgs(ap), PI_FORMAT_ARGS );
	        rtti->op = va_arg( ap, MPI_Op );
	    }
	    s = slash+1;
        }
	else rtti->op = MPI_OP_NULL;		// no reduce op

        /* Parse optional array size */
        if ( isdigit(*s) ) {
            count = 0;
            do {
                count = count * 10 + ( *s++ ) - '0';
            } while ( isdigit(*s) );
            PI_ASSERT( , *s != '\0', PI_FORMAT_INVALID );

            /* Disallow "%1" since 1 (one) looks too similar to l (ell).
               Also disallow "%0" as it has no meaning. */
            PI_ASSERT( , count > 1, PI_ARRAY_LENGTH );
        }

        /* '*' specifies array size supplied in int arg */
        if ( *s == '*' ) {
            /* Make sure the count has not already been specified */
            PI_ASSERT( , count == -1, PI_ARRAY_LENGTH );
	    /* Grab next arg for size */
////	    PI_ASSERT( LEVEL(2), MoreArgs(ap), PI_FORMAT_ARGS );
            count = va_arg( ap, int );
            PI_ASSERT( , count > 0, PI_ARRAY_LENGTH );
            s++;
            PI_ASSERT( , *s != '\0', PI_FORMAT_INVALID );
        }

        /* Figure out which MPI type to use */
        int skip = LookupConversionSpec( s, rtti );
        PI_ASSERT( , skip > 0, PI_FORMAT_INVALID );

	/* Here we may want to verify that a reduce operation is compatible
	   with the MPI type, but let's see if/how MPI detects problems. */

        /* Set `rtti->buf` to point to the appropriate data. */
        if ( valsOrLocs == IO_CONTEXT_LOCS || count >= 1 ) {
            if ( count <= 0 )
                // This is a Read into a Scalar.
                rtti->count = 1;
            else
                rtti->count = count;

            /* For user defined types, collect the datatype from the user */
            if ( rtti->cType == CTYPE_USER_DEFINED ) {
////		PI_ASSERT( LEVEL(2), MoreArgs(ap), PI_FORMAT_ARGS );
                rtti->type = va_arg( ap, MPI_Datatype );
	    }

////	    PI_ASSERT( LEVEL(2), MoreArgs(ap), PI_FORMAT_ARGS );
            rtti->data.address = va_arg( ap, void* );
            rtti->buf = rtti->data.address;
        }
        else if ( valsOrLocs == IO_CONTEXT_VALS ) {
            /* Writing a single scalar => copy it into a buffer */
////	    PI_ASSERT( LEVEL(2), MoreArgs(ap), PI_FORMAT_ARGS );
            rtti->count = 1;
            switch ( rtti->cType ) {
                case CTYPE_CHAR:
                    rtti->data.c = ( char )va_arg( ap, int );
                    rtti->buf = &rtti->data.c;
                    break;
                case CTYPE_SHORT:
                    rtti->data.h = ( short )va_arg( ap, int );
                    rtti->buf = &rtti->data.h;
                    break;
                case CTYPE_INT:
                    rtti->data.d = va_arg( ap, int );
                    rtti->buf = &rtti->data.d;
                    break;
                case CTYPE_LONG:
                    rtti->data.ld = va_arg( ap, long int );
                    rtti->buf = &rtti->data.ld;
                    break;
                case CTYPE_UNSIGNED_CHAR:
                    rtti->data.hhu = ( unsigned char )va_arg( ap, unsigned int );
                    rtti->buf = &rtti->data.hhu;
                    break;
                case CTYPE_UNSIGNED_SHORT:
                    rtti->data.hu = ( unsigned short )va_arg( ap, unsigned int );
                    rtti->buf = &rtti->data.hu;
                    break;
                case CTYPE_UNSIGNED_LONG:
                    rtti->data.lu = va_arg( ap, unsigned long );
                    rtti->buf = &rtti->data.lu;
                    break;
                case CTYPE_UNSIGNED:
                    rtti->data.ld = va_arg( ap, unsigned int );
                    rtti->buf = &rtti->data.ld;
                    break;
                case CTYPE_FLOAT:
                    rtti->data.f = ( float )va_arg( ap, double );
                    rtti->buf = &rtti->data.f;
                    break;
                case CTYPE_DOUBLE:
                    rtti->data.lf = va_arg( ap, double );
                    rtti->buf = &rtti->data.lf;
                    break;
                case CTYPE_LONG_DOUBLE:
                    rtti->data.llf = va_arg( ap, long double );
                    rtti->buf = &rtti->data.llf;
                    break;
                case CTYPE_BYTE:
                    rtti->data.b = ( unsigned char )va_arg( ap, unsigned int );
                    rtti->buf = &rtti->data.b;
                    break;
                case CTYPE_LONG_LONG:
                    rtti->data.lld = va_arg( ap, long long int );
                    rtti->buf = &rtti->data.lld;
                    break;
                case CTYPE_UNSIGNED_LONG_LONG:
                    rtti->data.llu = va_arg( ap, unsigned long long int );
                    rtti->buf = &rtti->data.llu;
                    break;
                case CTYPE_USER_DEFINED:
                    rtti->type = va_arg( ap, MPI_Datatype );
////		    PI_ASSERT( LEVEL(2), MoreArgs(ap), PI_FORMAT_ARGS );
                    rtti->data.address = va_arg( ap, void* );
                    rtti->buf = rtti->data.address;
                    break;
                default:
                    PI_ASSERT( , 0, PI_SYSTEM_ERROR );
            }
        }
        else {
            PI_ASSERT( , 0, PI_SYSTEM_ERROR );
        }

        /* Move onto the next conversion specifier. */
        s += skip;
    }

    /* The format string is nothing but whitespace. */
    PI_ASSERT( , metaIndex != 0, PI_FORMAT_INVALID );
    /* The format string contains too many arguments. */
    PI_ASSERT( , metaIndex != PI_MAX_FORMATLEN, PI_FORMAT_ARGS );

    /* End of format string -- there should now be two PI_END args */
    PI_ASSERT( LEVEL(1), PI_END1==va_arg(ap,int) && PI_END2==va_arg(ap,int),
               PI_FORMAT_ARGS )

    return metaIndex;
}
