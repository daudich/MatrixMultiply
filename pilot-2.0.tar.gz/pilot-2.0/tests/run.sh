#!/bin/bash
mpirun -np 8 ./test_suite
